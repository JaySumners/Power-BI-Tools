#Clean the workspace
rm(list=ls())

message("Welcome!")

#Load libraries
message("Loading libraries . . .")

Pkg_load <- function(x) {
  if(!require(x,
              character.only = TRUE,
              quietly = TRUE,
              warn.conflicts = FALSE)){
    install.packages(x,
                     quiet = TRUE,
                     verbose = FALSE)
  }
  library(x,
          character.only = TRUE,
          quietly = TRUE,
          warn.conflicts = FALSE)
}

Pkg_load("tidyverse")
Pkg_load("jsonlite")

rm("Pkg_load")


### GET FILE AND LOCALHOST FROM USER ###
open_port <- function(file_path){
  ps_compliant_command <- 
    paste0(c('powershell \".\\powershell_scripts\\open_pbix.ps1\"',
             " \'",
             file_path,
             "\'"),
           collapse = "")
  
  port <- system(ps_compliant_command, intern = TRUE)
  return(max(port))
}

already_open_port <- function(file_name){
  PID <- open_pbix_files %>%
    filter(MainWindowTitle == file_name) %>%
    top_n(1,Id) %>%
    pull(Id)
  
  port <-
    paste('powershell \".\\powershell_scripts\\PID_to_port.ps1\"',
          PID,
          sep = " ") %>%
    system(., intern = TRUE)
  
  return(max(port))
}

message("Please choose the PBIX file you want evaluated . . .")
pbix_file_path <- choose.files(default = "",
                               caption="Choose PBIX file",
                               multi = FALSE,
                               filters = matrix(c("PBIX","*.pbix"), nrow = 1))

if(!(length(pbix_file_path)>0)){
  message("No pbix file was selected. Exiting script.")
} else {
  pbix_name <- pbix_file_path %>% 
    str_split("\\\\") %>% 
    as_vector() %>% 
    .[length(.)] %>% 
    str_extract(".*(?=.pbix)")
  
  open_pbix_files <-
    system('powershell \".\\powershell_scripts\\get_PID.ps1\"', intern=TRUE)
  
  if(length(open_pbix_files)>0){
    open_pbix_files <- open_pbix_files %>%
      .[. != ""] %>%
      str_trim(.) %>%
      str_split(., "\\s", n=2, simplify=TRUE) %>%
      as_tibble() %>%
      `colnames<-`(as.vector(t(.[1,]))) %>%
      slice(-1:-2) %>%
      mutate(MainWindowTitle = str_remove(MainWindowTitle,
                                          " - Power BI Desktop$"))
  } else {
    open_pbix_files <- tribble(~Id, ~MainWindowTitle)
  }


  if(pbix_name %in% open_pbix_files$MainWindowTitle){
    open_or_no <- winDialog(type = c("yesno"),"Would you like to use the PBIX file with this name that is already open?")
    
    if(open_or_no == "NO"){
      message("Opening PBIX file . . .")
      
      port <- open_port(pbix_file_path)
        
    } else {
      port <- already_open_port(pbix_name)
    }
    rm(open_pbix_files, open_or_no)
  } else {
    message("Opening PBIX file . . .")
    port <- open_port(pbix_file_path)
  }
  
  rm(open_port, already_open_port)
  
  #Extact file from PBIX, import, then remove now extraneous file
  extracted_path <- unzip(pbix_file_path, files = "Report/Layout", junkpaths = TRUE, overwrite = TRUE)
  
  con <- file(extracted_path,
              encoding = "UTF16LE")
  dat <- readLines(con, warn = FALSE) %>% fromJSON(.)
  close(con)
  
  file.remove(extracted_path)
  
  rm(list = c("con","extracted_path"))
  
  #Pull config information and manipulate
  config_data <- bind_rows(dat$sections) %>%
    select(displayName, visualContainers) %>%
    unnest(visualContainers)
  
  report_names <- config_data$displayName %>%
    as_vector()
  
  config_values <- map(config_data$config, fromJSON) %>% 'names<-'(report_names)
  
  #Function to break down prototypeQuery
  cleanup_fun <- function(y) {
    if(nrow(y)>0){
      y %>%
        drop_na() %>%
        mutate_all(as.character)
    }
  }
  
  prototypeQuery_fun <- function(x) {
    local_list <- x$singleVisual$prototypeQuery
    
    if(is.null(local_list)) {
      
      local_Objects <- data.frame("Table_Name" = NA, "Object_ID" = NA)
      
    } else {
      
      local_Tables <- bind_rows(local_list$From) %>%
        `colnames<-`(c("Table_ID", "Table_Name"))
      
      local_Measures <- data.frame("Table_ID" = local_list$Select$Measure$Expression$SourceRef$Source,
                                   "Object_ID" = local_list$Select$Measure$Property)
      
      local_Columns <- data.frame("Table_ID" = local_list$Select$Column$Expression$SourceRef$Source,
                                  "Object_ID" = local_list$Select$Column$Property)
      
      local_Aggregations <- data.frame("Table_ID" = local_list$Select$Aggregation$Expression$Column$Expression$SourceRef$Source, 
                                       "Object_ID" = local_list$Select$Aggregation$Expression$Column$Property)
      
      local_Objects <- map_df(list(local_Measures, local_Columns, local_Aggregations), cleanup_fun) %>%
        left_join(local_Tables, by="Table_ID") %>%
        select(Table_Name, Object_ID)
    }
    
    return(local_Objects)
  }
  
  # Final dataframe creation
  message("Configuring table of page visuals . . .")
  
  Objects_df <- map(config_values, prototypeQuery_fun) %>%
    bind_rows(.id="Report_Page") %>%
    filter(!is.na(Object_ID)) %>%
    distinct() %>%
    mutate(Complete_Object_Name = paste("'",.$Table_Name, "'[", .$Object_ID, "]", sep = "")) %>%
    'colnames<-'(c("Report Page", "Table", "Column/Measure", "Complete_Object_Name"))
  
  # Remove unnecessary objects
  rm(list=c("config_data",
            "config_values",
            "dat",
            "report_names",
            "prototypeQuery_fun",
            "cleanup_fun"))
  
  #Run queries and find not referenced objects
  message("Pulling model data . . .")
  
  #Fine to use Format-Table due to shorter name lengths.
  tables_data <-
    paste('powershell \".\\powershell_scripts\\get_tables.ps1\"',
          port,
          sep = " ") %>%
    system(., intern = TRUE) %>%
    .[. != ""] %>%
    str_trim(.) %>%
    str_split(., "\\s{2,}", n=2, simplify=TRUE) %>%
    as_tibble() %>%
    `colnames<-`(as.vector(t(.[1,]))) %>%
    slice(-1:-2) %>%
    rename("Table_ID" = "DIMENSION_UNIQUE_NAME", "Table" = "DIMENSION_NAME")

  # Original style using Format-Table. Failed because some names got too close to the description and made it difficult to separate them. Forced to use a list. Note: the list method removes any wrapped descriptions.
  # columns_data <-
  #   paste('powershell \".\\powershell_scripts\\get_columns.ps1\"',
  #         port,
  #         sep = " ") %>%
  #   system(., intern = TRUE) %>%
  #   .[. != ""] %>%
  #   str_trim(.) %>%
  #   str_split(., "\\s{2,}", n=3, simplify=TRUE) %>%
  #   as_tibble() %>%
  #   `colnames<-`(as.vector(t(.[1,]))) %>%
  #   slice(-1:-2) %>%
  #   rename("Table_ID" = "DIMENSION_UNIQUE_NAME",
  #          "Object_Name" = "HIERARCHY_NAME",
  #          "Description" = "DESCRIPTION") %>%
  #   left_join(tables_data %>% select(Table_ID, Table), by="Table_ID") %>%
  #   select(Table, Object_Name, Description)
  
  
  columns_data <- 
    paste('powershell \".\\powershell_scripts\\get_columns_2.ps1\"',
          port,
          sep = " ") %>%
    system(., intern = TRUE) %>%
    enframe() %>%
    select(-name) %>%
    filter(value != "") %>%
    separate(col = value,
             into = c("A", "B"),
             sep = ":",
             extra = "drop",
             fill = "right") %>%
    mutate_all(str_trim) %>%
    filter(!is.na(B)) %>%
    mutate("Split_Val" = cumsum(A == "DIMENSION_UNIQUE_NAME")) %>%
    spread(A, B) %>%
    select(-Split_Val) %>%
    rename("Table_ID" = "DIMENSION_UNIQUE_NAME",
           "Object_Name" = "HIERARCHY_NAME",
           "Description" = "DESCRIPTION") %>%
    left_join(tables_data %>% select(Table_ID, Table), by="Table_ID") %>%
    select(Table, Object_Name, Description)
  
  # Old code. Same potential problem with Format-Table.
  # measures_data <-
  #   paste('powershell \".\\powershell_scripts\\get_measures.ps1\"',
  #         port,
  #         sep = " ") %>%
  #   system(., intern = TRUE) %>%
  #   .[. != ""] %>%
  #   str_trim(.) %>%
  #   str_split(., "\\s{2,}", n=3, simplify=TRUE) %>%
  #   as_tibble() %>%
  #   `colnames<-`(as.vector(t(.[1,]))) %>%
  #   slice(-1:-2) %>%
  #   rename("Table" = "MEASUREGROUP_NAME",
  #          "Object_Name" = "MEASURE_NAME",
  #          "Description" = "DESCRIPTION")
  
  measures_data <-
    paste('powershell \".\\powershell_scripts\\get_measures_2.ps1\"',
          port,
          sep = " ") %>%
    system(., intern = TRUE) %>%
    enframe() %>%
    select(-name) %>%
    filter(value != "") %>%
    separate(col = value,
             into = c("A", "B"),
             sep = ":",
             extra = "drop",
             fill = "right") %>%
    mutate_all(str_trim) %>%
    filter(!is.na(B)) %>%
    mutate("Split_Val" = cumsum(A == "MEASUREGROUP_NAME")) %>%
    spread(A, B) %>%
    select(-Split_Val) %>%
    filter(!is.na(MEASUREGROUP_NAME)) %>%
    rename("Table" = "MEASUREGROUP_NAME",
           "Object_Name" = "MEASURE_NAME",
           "Description" = "DESCRIPTION")
  
  combined_data <- bind_rows(columns_data, measures_data) %>%
    mutate("Object" = paste("'",.$Table,"'[",.$Object_Name,"]", sep = "")) %>%
    select(Object, Description) %>%
    filter(!(Object %in% c("'Measures'[Measures]", "'NA'[__Default measure]"))) %>%
    distinct()
  
  depend_data <-
    paste('powershell \".\\powershell_scripts\\get_dependencies.ps1\"',
          port,
          sep = " ") %>%
    system(., intern = TRUE) %>%
    enframe() %>%
    select(-name) %>%
    filter(value != "") %>%
    separate(col = value, into = c("A", "B"), sep = ":", extra = "drop") %>%
    mutate_all(str_trim) %>%
    mutate("Split_Val" = cumsum(A == "TABLE")) %>%
    spread(A, B) %>%
    select(-Split_Val) %>%
    mutate("Object" = paste("'",.$TABLE,"'[",.$OBJECT,"]", sep=""),
           "Reference" = paste("'",.$REFERENCED_TABLE, "'[",.$REFERENCED_OBJECT,"]", sep="")) %>%
    select(Object, Reference) %>%
    distinct() %>%
    arrange(Object, Reference)
  
  rm(list=c("tables_data",
            "columns_data",
            "measures_data"))
  
  message("Evaluating data . . .")
  
  All_Objects <- combined_data$Object %>% unique()
  
  Page_Referenced <- Objects_df$Complete_Object_Name %>% unique()
  
  Page_Reduced <- setdiff(All_Objects, Page_Referenced)
  
  i <- 0
  dd <- depend_data
  MR_pass <- dd$Reference %>% unique()
  NR_pass <- Page_Reduced %>% setdiff(., MR_pass)
  
  while (i < 100 & length(intersect(NR_pass,dd$Object)) > 0) {
    writeLines(paste("Pass ",
                     i,
                     ": ",
                     length(intersect(NR_pass,dd$Object)),
                     " additional removals needed",
                     sep = ""))
    
    dd <- depend_data %>%
      filter(!(.$Object %in% NR_pass))
    
    MR_pass <- dd$Reference %>% unique()
    
    NR_pass <- Page_Reduced %>%
      setdiff(.,MR_pass)
    
    i <- i+1
  }
  
  if (i == 100) {
    NR_pass <- "Maximum Iterations Reached (100)"
  } else {
    Not_Referenced <- NR_pass %>%
      data.frame("Object_Name" = ., stringsAsFactors = FALSE) %>%
      left_join(combined_data, by=c("Object_Name" = "Object")) %>%
      separate(Object_Name, c(NA,"Table","Object"), sep = "'") %>%
      select(Table, Object, Description) %>%
      filter(Table !="NA") %>%
      arrange(Table, Object)
  }
  
  rm(list=c("All_Objects",
            "Page_Referenced",
            "depend_data",
            "Objects_df",
            "combined_data",
            "dd",
            "MR_pass",
            "NR_pass",
            "i",
            "Page_Reduced"))
  
  
  # Write final dataframe to CSV
  message("Writting CSV . . .")
  
  write.folder <- choose.dir(default = getwd(),
                             caption = "Select a folder to house the CSV file\nClick Cancel to use the working directory") %>%
    ifelse(is.na(.),normalizePath(getwd(),winslash = "\\"),.)
  
  csv_name <- paste("Unused Objects (", pbix_name, ").csv", sep = "")
  
  write_csv(Not_Referenced, paste0(c(write.folder, csv_name), collapse = "\\"))
  
  #Close the PBIX
  message("Closing PBIX file . . .")
  close_or_no <- winDialog(type = c("yesno"),"Would you like to close the PBIX file?")
  
  if(close_or_no == "YES"){
    system(
      paste('powershell \".\\powershell_scripts\\close_pbix.ps1\"',
            pbix_name,
            sep = " ")
    )
  }
  
  rm(close_or_no,
     pbix_file_path)
  
  message("Complete!")
  
}



