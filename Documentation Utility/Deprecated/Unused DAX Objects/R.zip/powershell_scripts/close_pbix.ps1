$filename = $args[0]
$filenameval = $filename + "*"

#Get PID
$PID_val = (Get-Process PBIDesktop | where MainWindowTitle -Like $filenameval).id

#Stop the process
Stop-Process -Id $PID_val