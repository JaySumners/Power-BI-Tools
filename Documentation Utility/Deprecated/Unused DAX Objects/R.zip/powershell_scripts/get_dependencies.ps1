#Set port number and go
$port = [int]$args[0]

#Getting the data sources from the $Embedded$ tabular model
[xml] $db = Invoke-ASCmd -Server:localhost:$port -Query:"SELECT * from `$SYSTEM.DISCOVER_CALC_DEPENDENCY"
$cs = $db.return.root.row | Format-List -Property TABLE, OBJECT, REFERENCED_TABLE, REFERENCED_OBJECT
$cs