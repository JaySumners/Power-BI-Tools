#Open file and start process
$filename_local = $args[0]
Start-Process -FilePath $filename_local | Out-Null

#Finding the portnumber on which the $Embedded$ tabular model is running on
$embedded = "$env:LOCALAPPDATA\Microsoft\Power BI Desktop\AnalysisServicesWorkspaces"

do{
	$ports = Get-ChildItem $embedded -rec | where {$_.Name -eq "msmdsrv.port.txt"}
}
while([string]::IsNullOrEmpty($ports))

$port = Get-Content $ports.FullName -Encoding Unicode

#Return the port number
$port