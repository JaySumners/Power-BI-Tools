$all_files = Get-Childitem �Path C:\ *.pbix -File -Recurse -ErrorAction SilentlyContinue
$file_paths = $test | ForEach-Object {if ($_.Name.Contains('test.pbix')) {$_.Directory.ToString()}}

$file_paths