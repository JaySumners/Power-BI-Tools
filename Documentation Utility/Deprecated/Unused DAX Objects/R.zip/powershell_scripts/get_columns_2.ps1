#Set port number and go
$port = [int]$args[0]

#Getting the data sources from the $Embedded$ tabular model
[xml] $db = Invoke-ASCmd -Server:localhost:$port -Query:"SELECT * from `$SYSTEM.MDSCHEMA_HIERARCHIES"
$cs = $db.return.root.row | Format-List -Property DIMENSION_UNIQUE_NAME, HIERARCHY_NAME, DESCRIPTION
$cs