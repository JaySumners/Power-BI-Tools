# -*- coding: utf-8 -*-
"""
Created on Mon Jul 29 16:07:03 2019

@author: jsumners
"""
#Clean the workspace
#%reset -f

print('Welcome!')

#Get the working directory
print("Please select the directory this script is in")
from tkinter import Tk
from tkinter.filedialog import askdirectory
root = Tk()
root.withdraw() 
working_path = askdirectory()
root.update()

import os
os.chdir(working_path)

#Early functions
def open_port(file_path):
    '''Will get the port when opening a PBIX file'''
    print("Opening PBIX file . . .")
    from shlex import quote
    import subprocess
    command = 'powershell ' + '\".\\powershell_script\\open_pbix.ps1 ' + quote(file_path) + '\"'
    p = subprocess.run(command, capture_output=True)
    return int(p.stdout)
    
def already_open_port(file_name):
    '''Will get the port when the PBIX file is already open'''
    from shlex import quote
    import subprocess
    command = 'powershell ' + '\".\\powershell_script\\open_pbix.ps1 ' + quote(file_name) + '\"'
    p = subprocess.run(command, capture_output=True)
    return int(p.stdout)

#Get the filename
print("Please choose the PBIX file you want evaluated . . .")

from tkinter import Tk
from tkinter.filedialog import askopenfilename
root = Tk()
root.withdraw() 
filename = askopenfilename(filetypes=(("PBIX files", "*.pbix"),
                                       ("All files", "*.*")),
                            title='Select PBIX Path')
root.update()


#If statement that contains the rest of the code
if len(filename) == 0:
    raise Exception("No pbix file was selected. Exiting script.")
else:
    pbix_name = filename.split('/')[-1][:-5]
    
    from shlex import quote
    import subprocess
    p = subprocess.run('powershell ' + '\".\\powershell_script\\get_PID.ps1\"', capture_output=True, text=True)
    open_pbix_files = p.stdout
    
    #More libraries    
    import re
    import pandas as pd
    import numpy as np
    
    #Determine open_pbix_file contents
    if len(open_pbix_files) > 0:
        open_pbix_files = [re.split('\s', x.strip(), maxsplit=1) for x in open_pbix_files.split("\n") if x != '']
        open_pbix_files = pd.DataFrame(open_pbix_files[2:], columns=open_pbix_files[0])
        open_pbix_files['MainWindowTitle'] = [re.sub(' - Power BI Desktop$','',x) for x in open_pbix_files.MainWindowTitle]       
    else:
        open_pbix_files = pd.DataFrame({'Id':[], 'MainWindowTitle':[]})
        
 
    #Open the PBIX or otherwise get the port number
    if open_pbix_files.MainWindowTitle.isin([pbix_name]).any():
            from tkinter import Tk
            from tkinter import messagebox
            root = Tk()
            root.withdraw() 
            open_or_no = messagebox.askyesno(title='Selected PBIX file is open',
                                             message='Would you like to use the PBIX file with this name that is already open?')
            root.update()
            
            if open_or_no:
                port = already_open_port(pbix_name)
            else:
                port = open_port(filename)
            
    else:
        port = open_port(filename)
        
    #Extract file from PBIX< import, then remove now extraneous file
    from zipfile import ZipFile
    with ZipFile(filename, 'r') as zip_ref:
        with zip_ref.open('Report/Layout', 'r') as myfile:
            data = myfile.read()
    
    import json
    dat = json.loads(data)
  
    config_data = pd.DataFrame.from_dict(dat['sections']).loc[:,['displayName', 'visualContainers']]  
    config_data['visualContainers'] = config_data['visualContainers'].apply(pd.DataFrame.from_dict)
    config_data = pd.concat(config_data.visualContainers.tolist(),
                            keys=config_data.displayName.tolist(),
                            names=["Page", "Row"],
                            sort=False)#.reset_index(level=['Page']).reset_index(drop=True)
    
    config_values = config_data.config.apply(json.loads).reindex_like(config_data)
    
    def cleanup_fun(y):
        if len(y.index) >0:
            return y.dropna().astype(str)


    def prototypeQuery_fun(x):
        if 'prototypeQuery' in x['singleVisual'].keys():
            local_list = x['singleVisual']['prototypeQuery']
            
            #Get tables
            local_tables = pd.DataFrame.from_dict(local_list['From']).rename(columns={"Entity":"Table_Name", "Name":"Table_ID"})
            
            #Main search-through
            select_list = pd.DataFrame.from_dict(local_list['Select'])
            select_keys = select_list.columns.tolist()
            
            #Get Measures
            if 'Measure' in select_keys:
                local_measures = pd.concat(select_list['Measure'].dropna().apply(pd.DataFrame.from_dict).tolist()).rename(columns={'Expression':'Table_ID', 'Property':'Object_ID'})
                local_measures['Table_ID'] = local_measures['Table_ID'].apply(lambda x: x['Source'])
            else:
                local_measures = pd.DataFrame({'Table_ID':[], 'Object_ID':[]})
            
            #Get Columns
            if 'Column' in select_keys:
                local_columns = pd.concat(select_list['Column'].dropna().apply(pd.DataFrame.from_dict).tolist()).rename(columns={'Expression':'Table_ID', 'Property':'Object_ID'})
                local_columns['Table_ID'] = local_columns['Table_ID'].apply(lambda x: x['Source'])   
            else:
                local_columns = pd.DataFrame({'Table_ID':[], 'Object_ID':[]})
            
            #Get Aggregations
            if 'Aggregation' in select_keys:
                local_aggregation = pd.concat(pd.concat(select_list['Aggregation'].dropna().apply(pd.DataFrame.from_dict).tolist())['Expression'].apply(pd.DataFrame.from_dict).tolist()).rename(columns={'Expression':'Table_ID', 'Property':'Object_ID'})
                local_aggregation['Table_ID'] = local_aggregation['Table_ID'].apply(lambda x: x['Source'])
            else:
                local_aggregation = pd.DataFrame({'Table_ID':[], 'Object_ID':[]})
            
            #Bring it all together
            local_objects = pd.concat([local_measures, local_columns, local_aggregation]).apply(cleanup_fun)
            local_objects = local_objects.merge(local_tables, on='Table_ID').loc[:,['Table_Name','Object_ID']]          
            
        else:
            local_objects = pd.DataFrame({'Table_Name':[pd.NaT], 'Object_ID':[pd.NaT]})
            
        return local_objects
    
    
    #Final Dataframe creation
    print("Configuring table of page visuals . . .")
    objects_df = pd.concat(config_values.apply(prototypeQuery_fun).to_dict(),
                           names=["Page","RowID1","RowID2"],
                           sort=False).reset_index(level=['Page']).dropna().drop_duplicates().reset_index(drop=True)
    
    
    objects_df['complete_object_name'] = "'" + objects_df.Table_Name + "'[" + objects_df.Object_ID + "]"
    #Note: I didn't change the column names
    
    #Run queries and find not referenced objects
    print("Pulling model data . . .")
    #Tables
    command = 'powershell ' + '\".\\powershell_script\\get_tables.ps1 ' + quote(str(port)) + '\"'
    p = subprocess.run(command, capture_output=True, text=True)
    tables_data = [re.split('\s{2,}', x.strip(), maxsplit=1) for x in p.stdout.split("\n") if x != '']
    tables_df = (
                pd.DataFrame(
                        tables_data[2:],
                        columns=tables_data[0]
                        )
                .rename(
                        columns={"DIMENSION_UNIQUE_NAME": "Table_ID",
                                 "DIMENSION_NAME": "Table"}
                        )
            )

    #Columns
    command = 'powershell ' + '\".\\powershell_script\\get_columns.ps1 ' + quote(str(port)) + '\"'
    p = subprocess.run(command, capture_output=True, text=True)
    columns_data = [re.split('\s{2,}', x.strip(), maxsplit=2) for x in p.stdout.split("\n") if x != '']
    columns_df = (
                pd.DataFrame(
                        columns_data[2:],
                        columns=columns_data[0]
                        )
                .rename(
                        columns={"DIMENSION_UNIQUE_NAME": "Table_ID",
                                 "HIERARCHY_NAME": "Object_Name",
                                 "DESCRIPTION": "Description"}
                        )
                .merge(
                        tables_df, 
                        how='left', 
                        on='Table_ID'
                        )
                .loc[:,["Table","Object_Name","Description"]]
            )
 
    #Measures
    command = 'powershell ' + '\".\\powershell_script\\get_measures.ps1 ' + quote(str(port)) + '\"'
    p = subprocess.run(command, capture_output=True, text=True)
    measures_data = [re.split('\s{2,}', x.strip(), maxsplit=2) for x in p.stdout.split("\n") if x != '']
    
    measures_df = (
                pd.DataFrame(
                        measures_data[2:], 
                        columns=measures_data[0]
                        )
                .rename(
                        columns={"MEASUREGROUP_NAME": "Table",
                                 "MEASURE_NAME": "Object_Name",
                                 "DESCRIPTION":"Description"}
                        )
            )
       
    #Combined
    combined_df = columns_df.append(measures_df)
    combined_df['Object'] = (
                "'" 
                + combined_df.Table 
                + "'[" + combined_df.Object_Name 
                + "]"
            )
    combined_df = (
                combined_df
                .loc[
                        -combined_df.Object.isin(["'Measures'[Measures]", "'NA'[_Default measure]"]),
                        ["Object", "Description"]
                    ]
                .drop_duplicates()
            )
    
    #Dependencies
    command = 'powershell ' + '\".\\powershell_script\\get_dependencies.ps1 ' + quote(str(port)) + '\"'
    p = subprocess.run(command, capture_output=True, text=True)
    #A series of loops
    depend_data = re.split("\n\n",p.stdout)
    depend_data = [re.split('\n', x) for x in depend_data if x != '']
    depend_data = [[re.split(':', y, maxsplit=2) for y in x] for x in depend_data]
    depend_data = [[[z.strip() for z in y] for y in x] for x in depend_data]
    depend_data = [{y[0]:[y[1]] for y in x} for x in depend_data]
    depend_data = [pd.DataFrame.from_dict(x) for x in depend_data]
    #Now bring it together
    depend_data = pd.concat(depend_data, sort=False).fillna('NA')
    depend_data['Object'] = (
                "'" 
                + depend_data.TABLE 
                + "'[" 
                + depend_data.OBJECT 
                + "]"
            )
    depend_data['Reference'] = (
                "'" 
                + depend_data.REFERENCED_TABLE 
                + "'[" 
                + depend_data.REFERENCED_OBJECT 
                + "]"
            )
    depend_data = (
                depend_data
                .loc[:,['Object', 'Reference']]
                .drop_duplicates()
                .sort_values(by=['Object', 'Reference'])
                .reset_index(drop=True)
            )

    print("Evaluating data . . .")
    all_objects = set(combined_df.Object)
    page_referenced = set(objects_df.complete_object_name)
    page_reduced = all_objects.difference(page_referenced)
  
    i = 0
    dd = depend_data.copy()
    mr_pass = set(dd.Reference)
    nr_pass = page_reduced.difference(mr_pass)
  
    while (i < 100) and (len(nr_pass.intersection(set(dd.Object))) > 0):
        print('Pass ' + str(i) + ': ' + str(len(nr_pass.intersection(set(dd.Object)))) + ' additional removals needed')
        
        dd = depend_data[-depend_data.Object.isin(nr_pass)].copy()
        
        mr_pass = set(dd.Reference)
        nr_pass = page_reduced.difference(mr_pass)
        
        i += 1
        
    if i==100:
        nr_pass = 'Maximum Iterations Reached (100)'
    else:
        not_referenced = (
                    pd.DataFrame(list(nr_pass), columns=['object_name'])
                    .dropna()
                    .reset_index(drop=True)
                    .merge(combined_df, how='left', left_on='object_name', right_on='Object')
                )
        
        not_referenced = (
                    pd.DataFrame(
                            [re.split("'",x,maxsplit=3) for x in not_referenced.object_name.tolist()], 
                            columns=['NA','Table','Object']
                            )
                    .loc[:,['Table', 'Object']]
                    .join(
                            not_referenced
                            .loc[:,['Description']]
                            )
                    .sort_values(by=['Table', 'Object'])
                    .reset_index(drop=True)
                )
        
        #Export the data
        print("Writting CSV . . .")
        from tkinter import Tk
        from tkinter.filedialog import askdirectory
        root = Tk()
        root.withdraw() 
        write_folder = askdirectory()
        root.update()
        
        if len(write_folder)==0:
            from os import getcwd
            write_folder = getcwd()
        
        csv_name = write_folder + '\\Unused Objects (' + pbix_name + ').csv'
        
        not_referenced.to_csv(path_or_buf = csv_name, index=False)
        
        #Now close the pbix file
        print("Closing PBIX file . . .")
        from tkinter import Tk
        from tkinter import messagebox
        root = Tk()
        root.withdraw() 
        close_or_no = messagebox.askyesno(title='Close the PBIX file?',
                                          message='Would you like to close the PBIX file?')
        root.update()
        
        if close_or_no:
            from shlex import quote
            import subprocess
            command = 'powershell ' + '\".\\powershell_script\\close_pbix.ps1 ' + quote(pbix_name) + '\"'
            p = subprocess.run(command, capture_output=True)
            
        print("Complete!")
        
