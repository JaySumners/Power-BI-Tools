#Take open PID value and go get port number
$PID_val = [int]$args[0]
$ports = Get-NetTCPConnection -OwningProcess $PID_val | where RemotePort -ne 0
$port = $ports.RemotePort | Get-Unique
$port




