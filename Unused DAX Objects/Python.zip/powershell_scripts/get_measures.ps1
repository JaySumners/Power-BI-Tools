#Set port number and go
$port = [int]$args[0]

#Getting the data sources from the $Embedded$ tabular model
[xml] $db = Invoke-ASCmd -Server:localhost:$port -Query:"SELECT * from `$SYSTEM.MDSCHEMA_MEASURES"
$cs = $db.return.root.row | Format-Table -Property MEASUREGROUP_NAME, MEASURE_NAME, DESCRIPTION -AutoSize
$cs