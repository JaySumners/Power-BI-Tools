#Get any PBIX processes open and their PID
Get-Process PBIDesktop -ErrorAction SilentlyContinue | Format-Table -Property Id, MainWindowTitle